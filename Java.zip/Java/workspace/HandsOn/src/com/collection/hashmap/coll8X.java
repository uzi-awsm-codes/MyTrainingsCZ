/*8.Write a program that construts a hashmap with �state� as key and �capital� as its value. If the next input is a state, then it should return capital$state in lowercase.*/
package com.collection.hashmap;

import java.util.*;

/*
public class coll8X {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
*/

