select distinct a.deptname as "Worker Department",a.location as Location,d.deptname as "Manager Department"
from department d,
(select mgrno,deptname,location,admrdept from employee,department) as a
where d.deptname !=a.deptname and a.admrdept=d.deptno
order by a.deptname
go