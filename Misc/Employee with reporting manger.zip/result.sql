select concat(query.lastname," works for ",e.lastname)as Hierarchy from employee e,
(select lastname,mgrno from employee,department where workdept=deptno)as query
where e.empno=query.mgrno and query.lastname!=e.lastname
order by query.lastname
go