using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals2  //DO NOT change the namespace name
{
    public class Program      //DO NOT change the class name
    {
        public static void Main(string[] args)     //DO NOT change the 'Main' method signature
        {
            //Implement the code here
            double picost,pucost,pecost,gst,cess,total=0;
            Console.Write("Enter the number of pizzas bought:");
            int n1=Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the number of puffs bought:");
            int n2=Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the number of pepsi bought:");
            int n3=Convert.ToInt32(Console.ReadLine());
            
            picost=n1*200;
            pucost=n2*40;
            pecost=n3*120;
            total=(picost+pucost+pecost);
            gst=(total*0.12) ;
            cess=(total*0.05);
            
            Console.Write("\nBill Details \n\n");
            Console.Write("Cost of Pizzas :{0}\n",picost);
            Console.Write("Cost of Puffs :{0}\n",pucost);
            Console.Write("Cost of Pepsis :{0}\n", pecost);
            Console.Write("GST 12% :{0}\n", gst);
            Console.Write("CESS 5% :{0}\n", cess);
            Console.Write("Total Price :{0}",total);
        }
    }
}
